<?php
declare(strict_types=1);

if (!is_file(DEMO_DB_FILE) && !copy(__DIR__ . '/../demo-seed.sqlite', DEMO_DB_FILE)) {
    throw new RuntimeException('Не удалось открыть базу демонстрационных данных');
}
$pdo = new PDO('sqlite:' . DEMO_DB_FILE, null, null, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
]);
$pdo->exec('PRAGMA foreign_keys = ON; PRAGMA busy_timeout = 3000;');
$pdo->sqliteCreateFunction('concat', static fn (...$parts) => implode('', $parts));
$pdo->sqliteCreateFunction('rand', static fn ($min = 0, $max = 32767) => mt_rand($min, $max));
